# Muhammad Rizky Langit Arifi — Portfolio

Student portfolio website for Computer Engineering projects.

## Contents
- Profile and skills
- FIR Digital Filter (MATLAB / Signal Processing)
- Arduino Uno Push Button & LED simulation (Tinkercad / Wokwi)
- Certificates list
- Contact links

## Publish using GitHub Pages
1. Create a public repository named `rizky-portfolio`.
2. Upload `index.html` and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish your site.

